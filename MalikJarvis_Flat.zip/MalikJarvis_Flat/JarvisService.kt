package com.malik.jarvis

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech

class JarvisService : Service() {
    private var loop: VoiceLoop? = null
    private var tts: TextToSpeech? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Malik Jarvis", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Malik Jarvis")
            .setContentText(Lang.t(this, "سن رہا ہوں… ایپ کا نام بولیں", "Listening… say an app name"))
            .setSmallIcon(R.drawable.ic_stat_jarvis).setContentIntent(pi).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { }
        loop = VoiceLoop(this) { text ->
            Jarvis.handle(this, text) { Lang.speak(tts, this, it) }
        }
        loop?.start()
    }

    override fun onDestroy() { loop?.stop(); tts?.shutdown(); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
