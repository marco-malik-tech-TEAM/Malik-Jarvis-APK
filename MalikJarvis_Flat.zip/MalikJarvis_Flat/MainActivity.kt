package com.malik.jarvis

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var tts: TextToSpeech? = null
    private var loop: VoiceLoop? = null
    private lateinit var status: TextView
    private lateinit var bg: Switch

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { begin() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        tts = TextToSpeech(this) { }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply { text = "Malik Jarvis"; textSize = 34f; gravity = Gravity.CENTER })
        status = TextView(this).apply {
            text = Lang.t(this@MainActivity, "شروع کرنے کے لیے Start دبائیں", "Press Start to begin")
            gravity = Gravity.CENTER; setPadding(0, 32, 0, 32)
        }
        root.addView(status)
        root.addView(Button(this).apply { text = "Start"; setOnClickListener { askPermissions() } })
        bg = Switch(this).apply {
            text = Lang.t(this@MainActivity, "بیک گراؤنڈ نوٹیفکیشن  ", "Background Notification  ")
            setPadding(0, 48, 0, 0)
        }
        root.addView(bg)
        // Language switch: Urdu <-> English
        root.addView(Button(this).apply {
            text = if (Lang.isUrdu(this@MainActivity)) "English" else "اردو"
            setOnClickListener {
                Lang.setUrdu(this@MainActivity, !Lang.isUrdu(this@MainActivity))
                recreate()
            }
        })
        setContentView(root)
    }

    private fun askPermissions() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(p.toTypedArray())
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) { // needed so Jarvis can open apps while in background
            Toast.makeText(this, Lang.t(this, "Jarvis کو 'Display over other apps' کی اجازت دیں",
                "Allow 'Display over other apps' for Jarvis"), Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val n = Jarvis.loadApps(this).size
        status.text = Lang.t(this, "$n ایپس ملیں۔ اب ایپ کا نام بولیں", "$n apps found. Now say an app name")
        Lang.speak(tts, this, Lang.t(this, "جارویس تیار ہے۔ $n ایپس ملیں", "Jarvis is ready. $n apps found"))
        if (bg.isChecked) {
            startForegroundService(Intent(this, JarvisService::class.java))
            status.text = Lang.t(this, "Background میں چل رہا ہے۔ ایپ بند کر سکتے ہیں",
                "Running in background. You can close the app")
        } else {
            stopService(Intent(this, JarvisService::class.java))
            loop?.stop()
            loop = VoiceLoop(this) { text ->
                status.text = Lang.t(this, "آپ نے کہا: ", "You said: ") + text
                Jarvis.handle(this, text) { Lang.speak(tts, this, it) }
            }.also { it.start() }
        }
    }

    override fun onDestroy() { loop?.stop(); tts?.shutdown(); super.onDestroy() }
}
