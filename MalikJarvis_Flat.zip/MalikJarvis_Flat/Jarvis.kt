package com.malik.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

data class AppInfo(val label: String, val pkg: String)

object Jarvis {
    // Urdu spellings -> English app-name keyword (only Urdu + English are supported). Add more as needed.
    private val alias = mapOf(
        "whatsapp" to listOf("واٹس ایپ", "واٹس اپ", "وٹس ایپ", "واٹسایپ"),
        "youtube" to listOf("یوٹیوب", "یو ٹیوب"),
        "chrome" to listOf("کروم"),
        "camera" to listOf("کیمرا", "کیمرہ"),
        "settings" to listOf("سیٹنگ", "سیٹنگز", "سیٹنگس"),
        "gallery" to listOf("گیلری"),
        "phone" to listOf("فون"),
        "messages" to listOf("میسج", "میسجز"),
        "facebook" to listOf("فیس بک", "فیسبک"),
        "instagram" to listOf("انسٹاگرام", "انسٹا گرام"),
        "maps" to listOf("میپ", "میپس", "نقشہ"),
        "gmail" to listOf("جی میل", "جیمیل"),
        "telegram" to listOf("ٹیلی گرام", "ٹیلیگرام"),
        "tiktok" to listOf("ٹک ٹاک", "ٹکٹاک"),
        "snapchat" to listOf("اسنیپ چیٹ"),
        "play store" to listOf("پلے سٹور", "پلے اسٹور")
    )
    private val listWords = listOf("list", "apps", "فہرست", "کون سی ایپ", "کونسی ایپ")

    fun loadApps(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }

    fun handle(ctx: Context, spoken: String, say: (String) -> Unit) {
        val t = spoken.lowercase()
        val apps = loadApps(ctx)
        if (listWords.any { t.contains(it) }) {
            say(Lang.t(ctx, "آپ کے فون میں ${apps.size} ایپس ہیں۔ جیسے: ", "You have ${apps.size} apps. For example: ") +
                apps.take(10).joinToString(Lang.t(ctx, "، ", ", ")) { it.label })
            return
        }
        val hit = apps.firstOrNull { a ->
            val l = a.label.lowercase()
            t.contains(l) || alias.any { (k, v) -> l.contains(k) && v.any { t.contains(it) } }
        }
        val launch = hit?.let { ctx.packageManager.getLaunchIntentForPackage(it.pkg) }
        if (hit == null || launch == null) { say(Lang.t(ctx, "معاف کیجیے، یہ ایپ نہیں ملی", "Sorry, app not found")); return }
        say(Lang.t(ctx, "${hit.label} کھول رہا ہوں", "Opening ${hit.label}"))
        ctx.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Keeps listening, restarting after every result/error, until stop() is called. */
class VoiceLoop(private val ctx: Context, private val onText: (String) -> Unit) {
    private var sr: SpeechRecognizer? = null
    private var running = false
    private val h = Handler(Looper.getMainLooper())

    fun start() { running = true; listen() }
    fun stop() { running = false; h.removeCallbacksAndMessages(null); sr?.destroy(); sr = null }

    private fun listen() {
        if (!running) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle) {
                    b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText)
                    h.postDelayed({ listen() }, 1500)
                }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 1000) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Lang.recognizerTag(ctx)) // ur-PK or en-US
        sr?.startListening(i)
    }
}
