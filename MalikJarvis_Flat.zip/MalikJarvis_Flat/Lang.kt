package com.malik.jarvis

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** App supports only Urdu and English. Default = Urdu. */
object Lang {
    private const val PREFS = "jarvis"
    private const val KEY = "lang"

    fun isUrdu(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "ur") == "ur"
    fun setUrdu(c: Context, urdu: Boolean) =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, if (urdu) "ur" else "en").apply()

    fun t(c: Context, ur: String, en: String) = if (isUrdu(c)) ur else en
    fun recognizerTag(c: Context) = if (isUrdu(c)) "ur-PK" else "en-US"
    private fun locale(c: Context) = if (isUrdu(c)) Locale("ur", "PK") else Locale.US

    /** Speak in the selected language (falls back to English voice if Urdu voice is not installed). */
    fun speak(tts: TextToSpeech?, c: Context, text: String) {
        val e = tts ?: return
        val r = e.setLanguage(locale(c))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) e.setLanguage(Locale.US)
        e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "j")
    }
}
